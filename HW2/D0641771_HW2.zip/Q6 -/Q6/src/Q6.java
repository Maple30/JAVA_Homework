
public class Q6 {
	//Have no idea what to writeQAQ
}
